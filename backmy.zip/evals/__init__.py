from evals.evals import test_classifier, eval_ood_detection
